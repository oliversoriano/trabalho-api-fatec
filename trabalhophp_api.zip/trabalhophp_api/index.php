<?php
/**
 * Cadastro de Pessoa com preenchimento automático
 * - Endereço via API ViaCEP
 * - Dados da empresa via API ReceitaWS
 */

/** Escapa um valor para exibição segura no HTML (evita XSS). */
function e($valor)
{
    return htmlspecialchars((string) $valor, ENT_QUOTES, 'UTF-8');
}

/** Faz uma requisição GET e devolve o JSON decodificado, ou null em caso de falha. */
function buscarJson($url)
{
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 10,
        CURLOPT_USERAGENT      => 'trabalhophp_api',
    ]);
    $resposta = curl_exec($ch);
    curl_close($ch);

    return $resposta ? json_decode($resposta, true) : null;
}

$cepData  = null;
$cnpjData = null;
$erro     = '';

if (isset($_POST['buscarCep'])) {
    $cep = preg_replace('/\D/', '', $_POST['cep'] ?? ''); // mantém só os números

    if (strlen($cep) !== 8) {
        $erro = 'CEP inválido: informe 8 números.';
    } else {
        $cepData = buscarJson("https://viacep.com.br/ws/$cep/json/");
        if (!$cepData || isset($cepData['erro'])) {
            $erro = 'CEP não encontrado.';
            $cepData = null;
        }
    }
}

if (isset($_POST['buscarCnpj'])) {
    $cnpj = preg_replace('/\D/', '', $_POST['cnpj'] ?? ''); // mantém só os números

    if (strlen($cnpj) !== 14) {
        $erro = 'CNPJ inválido: informe 14 números.';
    } else {
        $cnpjData = buscarJson("https://receitaws.com.br/v1/cnpj/$cnpj");
        if (!$cnpjData || ($cnpjData['status'] ?? '') === 'ERROR') {
            $erro = $cnpjData['message'] ?? 'Não foi possível consultar o CNPJ. Tente novamente em instantes.';
            $cnpjData = null;
        }
    }
}

/** Valor do campo: prioriza o retorno da API e, se não houver, o que já foi digitado. */
function campo($nome, $dadosApi = null, $chaveApi = null)
{
    if ($dadosApi && $chaveApi && !empty($dadosApi[$chaveApi])) {
        return e($dadosApi[$chaveApi]);
    }
    return e($_POST[$nome] ?? '');
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Pessoa</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <main class="card">
        <h1>Cadastro de Pessoa</h1>

        <?php if ($erro): ?>
            <p class="alerta"><?= e($erro) ?></p>
        <?php endif; ?>

        <form method="POST">

            <fieldset>
                <legend>Dados Pessoais</legend>

                <label>Nome*
                    <input type="text" name="nome_usuario" required value="<?= campo('nome_usuario') ?>">
                </label>

                <div class="linha">
                    <label>Telefone
                        <input type="text" name="telefone_usuario" value="<?= campo('telefone_usuario') ?>">
                    </label>
                    <label>Email
                        <input type="email" name="email_usuario" value="<?= campo('email_usuario') ?>">
                    </label>
                </div>
            </fieldset>

            <fieldset>
                <legend>Dados da Empresa</legend>

                <label>CNPJ</label>
                <div class="busca">
                    <input type="text" name="cnpj" placeholder="00.000.000/0000-00" value="<?= campo('cnpj') ?>">
                    <button type="submit" name="buscarCnpj" formnovalidate>Buscar CNPJ</button>
                </div>

                <label>Nome Empresa
                    <input type="text" name="nome_empresa" readonly value="<?= campo('nome_empresa', $cnpjData, 'nome') ?>">
                </label>

                <div class="linha">
                    <label>Fantasia
                        <input type="text" name="fantasia" readonly value="<?= campo('fantasia', $cnpjData, 'fantasia') ?>">
                    </label>
                    <label>Telefone Empresa
                        <input type="text" name="telefone_empresa" readonly value="<?= campo('telefone_empresa', $cnpjData, 'telefone') ?>">
                    </label>
                </div>
            </fieldset>

            <fieldset>
                <legend>Endereço</legend>

                <label>CEP</label>
                <div class="busca">
                    <input type="text" name="cep" placeholder="00000-000" value="<?= campo('cep') ?>">
                    <button type="submit" name="buscarCep" formnovalidate>Buscar CEP</button>
                </div>

                <label>Rua
                    <input type="text" name="rua" readonly value="<?= campo('rua', $cepData, 'logradouro') ?>">
                </label>

                <div class="linha">
                    <label>Bairro
                        <input type="text" name="bairro" readonly value="<?= campo('bairro', $cepData, 'bairro') ?>">
                    </label>
                    <label>Cidade
                        <input type="text" name="cidade" readonly value="<?= campo('cidade', $cepData, 'localidade') ?>">
                    </label>
                    <label class="uf">Estado
                        <input type="text" name="estado" readonly value="<?= campo('estado', $cepData, 'uf') ?>">
                    </label>
                </div>
            </fieldset>

            <button type="submit" formaction="resultado.php" class="principal">Cadastrar Pessoa</button>
        </form>
    </main>
</body>

</html>
