<?php
/** Escapa um valor para exibição segura no HTML (evita XSS). */
function e($valor)
{
    return htmlspecialchars((string) $valor, ENT_QUOTES, 'UTF-8');
}

/** Lê um campo enviado pelo formulário. */
function post($nome)
{
    return e($_POST[$nome] ?? '');
}

// Acesso direto sem enviar o formulário: volta para o cadastro
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultado</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <main class="card">
        <h1>Pessoa cadastrada com sucesso!</h1>

        <section>
            <h2>Dados do Usuário</h2>
            <dl>
                <dt>Nome</dt><dd><?= post('nome_usuario') ?></dd>
                <dt>Telefone</dt><dd><?= post('telefone_usuario') ?></dd>
                <dt>Email</dt><dd><?= post('email_usuario') ?></dd>
            </dl>
        </section>

        <section>
            <h2>Empresa</h2>
            <dl>
                <dt>CNPJ</dt><dd><?= post('cnpj') ?></dd>
                <dt>Nome</dt><dd><?= post('nome_empresa') ?></dd>
                <dt>Fantasia</dt><dd><?= post('fantasia') ?></dd>
                <dt>Telefone</dt><dd><?= post('telefone_empresa') ?></dd>
            </dl>
        </section>

        <section>
            <h2>Endereço</h2>
            <dl>
                <dt>CEP</dt><dd><?= post('cep') ?></dd>
                <dt>Rua</dt><dd><?= post('rua') ?></dd>
                <dt>Bairro</dt><dd><?= post('bairro') ?></dd>
                <dt>Cidade</dt><dd><?= post('cidade') ?></dd>
                <dt>Estado</dt><dd><?= post('estado') ?></dd>
            </dl>
        </section>

        <a href="index.php" class="principal">Novo cadastro</a>
    </main>
</body>

</html>
